#!/bin/sh
# Run this ON the E52C after flashing. Busybox ash compatible.
#
#   sh verify-freq.sh                 # report
#   sh verify-freq.sh set 216000     # pin all clusters to 216 MHz
#   sh verify-freq.sh sweep          # walk every OPP, verify readback
#   sh verify-freq.sh persist 216000 # survive reboot via /etc/config/cpufreq
#   sh verify-freq.sh reset          # back to schedutil / full range
#
# NOTE: cpufreq.init (luci-app-cpufreq) re-applies UCI settings at boot, so
# manual writes alone are not persistent. Use "persist" for that.

CPUFREQ=/sys/devices/system/cpu/cpufreq
UCI_FILE=/etc/config/cpufreq

policies() { ls -d "$CPUFREQ"/policy[0-9]* 2>/dev/null; }

report() {
  echo "=== CPU count (8 = RK3582 core unlock active) ==="
  echo "  nproc = $(nproc)"
  echo "  online = $(cat /sys/devices/system/cpu/online)"
  echo
  echo "=== kernel / driver ==="
  uname -r
  for p in $(policies); do
    printf '  %s driver=%s governor=%s\n' \
      "$(basename "$p")" "$(cat "$p/scaling_driver")" "$(cat "$p/scaling_governor")"
  done
  echo
  echo "=== available frequencies (kHz) ==="
  for p in $(policies); do
    f=$(cat "$p/scaling_available_frequencies" 2>/dev/null)
    set -- $f
    echo "  $(basename "$p") [$# steps]: $f"
    [ -n "$1" ] && [ "$1" -lt 400000 ] \
      && echo "    -> OK: lowest is ${1} kHz (< 400 MHz)" \
      || echo "    -> FAIL: no sub-400 MHz OPP on this policy"
  done
  echo
  echo "=== current ==="
  for p in $(policies); do
    printf '  %s min=%s max=%s cur=%s\n' "$(basename "$p")" \
      "$(cat "$p/scaling_min_freq")" "$(cat "$p/scaling_max_freq")" \
      "$(cat "$p/scaling_cur_freq" 2>/dev/null || cat "$p/cpuinfo_cur_freq")"
  done
}

set_freq() {
  target="$1"
  for p in $(policies); do
    avail=$(cat "$p/scaling_available_frequencies")
    case " $avail " in
      *" $target "*) ;;
      *) echo "  $(basename "$p"): $target kHz not available, using nearest lower";
         target=$(for f in $avail; do [ "$f" -le "$target" ] && echo "$f"; done | tail -1)
         [ -z "$target" ] && target=$(for f in $avail; do echo "$f"; done | head -1) ;;
    esac
    # Order matters: lower min first, then cap max, then raise min to target.
    lowest=$(for f in $avail; do echo "$f"; done | head -1)
    echo "$lowest" > "$p/scaling_min_freq" 2>/dev/null
    echo "$target" > "$p/scaling_max_freq"
    echo "$target" > "$p/scaling_min_freq"
  done
  echo "Requested ${target} kHz. Readback:"
  for p in $(policies); do
    printf '  %s cur=%s\n' "$(basename "$p")" \
      "$(cat "$p/scaling_cur_freq" 2>/dev/null || cat "$p/cpuinfo_cur_freq")"
  done
}

sweep() {
  echo "Walking every OPP on policy0 (watch for hangs; Ctrl-C to abort)."
  p="$CPUFREQ/policy0"
  [ -d "$p" ] || { echo "no policy0"; return 1; }
  for f in $(cat "$p/scaling_available_frequencies"); do
    set_freq "$f" >/dev/null
    cur=$(cat "$p/scaling_cur_freq" 2>/dev/null || cat "$p/cpuinfo_cur_freq")
    printf '  target=%-8s readback=%s\n' "$f" "$cur"
  done
  echo "Sweep finished. If the box is still alive, all OPPs are usable."
}

persist() {
  target="$1"
  [ -f "$UCI_FILE" ] || { echo "$UCI_FILE not found - is luci-app-cpufreq installed?"; return 1; }
  i=0
  for p in $(policies); do
    idx=$(basename "$p" | sed 's/policy//')
    uci set "cpufreq.cpufreq.governor$idx=schedutil"
    uci set "cpufreq.cpufreq.minfreq$idx=$target"
    uci set "cpufreq.cpufreq.maxfreq$idx=$target"
    i=$((i+1))
  done
  uci commit cpufreq
  /etc/init.d/cpufreq restart
  echo "Pinned $i policies at $target kHz across reboots."
}

reset_all() {
  for p in $(policies); do
    avail=$(cat "$p/scaling_available_frequencies")
    lowest=$(for f in $avail; do echo "$f"; done | head -1)
    highest=$(for f in $avail; do echo "$f"; done | tail -1)
    echo "schedutil" > "$p/scaling_governor" 2>/dev/null || echo "ondemand" > "$p/scaling_governor"
    echo "$highest" > "$p/scaling_max_freq"
    echo "$lowest"  > "$p/scaling_min_freq"
  done
  if [ -f "$UCI_FILE" ]; then
    for p in $(policies); do
      idx=$(basename "$p" | sed 's/policy//')
      uci -q delete "cpufreq.cpufreq.governor$idx"
      uci -q delete "cpufreq.cpufreq.minfreq$idx"
      uci -q delete "cpufreq.cpufreq.maxfreq$idx"
    done
    uci commit cpufreq
  fi
  echo "Reset to full range / schedutil."
}

case "${1:-report}" in
  report)  report ;;
  set)     [ -n "${2:-}" ] || { echo "usage: $0 set <kHz>"; exit 1; }; set_freq "$2" ;;
  sweep)   sweep ;;
  persist) [ -n "${2:-}" ] || { echo "usage: $0 persist <kHz>"; exit 1; }; persist "$2" ;;
  reset)   reset_all ;;
  *) echo "usage: $0 [report|set <kHz>|sweep|persist <kHz>|reset]"; exit 1 ;;
esac

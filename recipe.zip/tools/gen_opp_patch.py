#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generate ImmortalWrt kernel patches that expose the *full* RK3588 CPU frequency
ladder in the device tree, including the sub-400 MHz operating points.

Why this works
--------------
The mainline kernel's arch/arm64/boot/dts/rockchip/rk3588-opp.dtsi deliberately
keeps only 5 OPPs for the A55 cluster (1008..1800 MHz) and 7 OPPs for each A76
cluster (1200..2400 MHz). All OPPs that "only differ in frequency but not in
voltage" were dropped when the table was upstreamed. That is why cpufreq on
ImmortalWrt / OpenWrt shows almost no selectable frequencies.

The clock driver, however, already supports a much denser ladder. In
drivers/clk/rockchip/clk-rk3588.c (Linux v6.12) the arrays
rk3588_cpulclk_rates[] / rk3588_cpub0clk_rates[] / rk3588_cpub1clk_rates[]
contain 96, 216, 312, 408, 600, 696, 816, 912, ... MHz. cpufreq-dt can only
switch to frequencies that exist in the OPP table, so the fix is simply to add
OPP nodes for those already-supported rates. No driver, no clock, no bootloader
change is required.

Sources (verified 2026-11-14):
  * Linux v6.12 drivers/clk/rockchip/clk-rk3588.c  (rate tables)
  * Linux v6.12 arch/arm64/boot/dts/rockchip/rk3588-opp.dtsi (upstream OPP table)
  * Radxa downstream kernel stable-5.10-rock5 rk3588s.dtsi (vendor voltage ladder)
  * ImmortalWrt openwrt-25.12 target/linux/rockchip/Makefile (kernel 6.12)

Usage:
  python3 gen_opp_patch.py                # regenerate all patches
"""

from __future__ import annotations

import difflib
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PATCH_DIR = ROOT / "patches"
BASE_FILE = PATCH_DIR / "upstream-rk3588-opp.dtsi.v6.12"
DTSI_PATH = "arch/arm64/boot/dts/rockchip/rk3588-opp.dtsi"

# ---------------------------------------------------------------------------
# Frequencies (kHz) actually implemented by the mainline RK3588 CPU clock
# driver. Every OPP we emit MUST be one of these, otherwise clk_set_rate()
# will round it to something else and cpufreq-dt will reject the OPP.
# ---------------------------------------------------------------------------
CLK_RATES_BIG = [
    2496000, 2400000, 2304000, 2208000, 2184000, 2088000, 2040000, 2016000,
    1992000, 1896000, 1800000, 1704000, 1608000, 1584000, 1560000, 1536000,
    1512000, 1488000, 1464000, 1440000, 1416000, 1392000, 1368000, 1344000,
    1320000, 1296000, 1272000, 1248000, 1224000, 1200000, 1104000, 1008000,
    912000, 816000, 696000, 600000, 408000, 312000, 216000, 96000,
]
CLK_RATES_LIT = [
    2208000, 2184000, 2088000, 2040000, 2016000, 1992000, 1896000, 1800000,
    1704000, 1608000, 1584000, 1560000, 1536000, 1512000, 1488000, 1464000,
    1440000, 1416000, 1392000, 1368000, 1344000, 1320000, 1296000, 1272000,
    1248000, 1224000, 1200000, 1104000, 1008000, 912000, 816000, 696000,
    600000, 408000, 312000, 216000, 96000,
]

# OPPs already present upstream (kHz) - these nodes are left untouched.
UPSTREAM_LIT = [1008000, 1200000, 1416000, 1608000, 1800000]
UPSTREAM_BIG = [1200000, 1416000, 1608000, 1800000, 2016000, 2208000, 2400000]

# Verified voltage ladder from upstream / vendor table (kHz -> microvolts).
VOLT_LIT = [
    (1008000, 675000), (1200000, 712500), (1416000, 762500),
    (1608000, 850000), (1800000, 950000),
]
VOLT_BIG = [
    (1200000, 675000), (1416000, 725000), (1608000, 762500),
    (1800000, 850000), (2016000, 925000), (2208000, 987500),
    (2400000, 1000000),
]

# E52C regulators: regulator-min-microvolt = <550000>,
#                  regulator-max-microvolt = <1050000>
REG_MIN_UV = 550000
REG_MAX_UV = 1050000
# Kept for compatibility with the upstream OPP triples (upper tolerance).
TOLERANCE_MAX_LIT = 950000
TOLERANCE_MAX_BIG = 1000000

LITE_LADDER = [96000, 216000, 312000, 408000, 600000, 816000, 1008000,
               1200000, 1416000, 1608000, 1800000, 2016000, 2208000, 2400000]


def ceil_voltage(freq_khz: int, ladder: list[tuple[int, int]]) -> int:
    """Use the voltage of the next *higher* known OPP (conservative, never
    undervolts a given frequency)."""
    for known_freq, volt in sorted(ladder):
        if known_freq >= freq_khz:
            return volt
    return sorted(ladder)[-1][1]


def voltage_for(freq_khz: int, ladder: list[tuple[int, int]], lowvolt: bool) -> int:
    if lowvolt and freq_khz < 408000:
        # Experimental: real power savings need lower voltage as well.
        # 600 mV is still above the E52C regulator floor (550 mV).
        return 600000
    return ceil_voltage(freq_khz, ladder)


def wanted_freqs(profile: str, rates: list[int], existing: list[int],
                 cap_khz: int) -> list[int]:
    if profile == "full":
        candidates = rates
    elif profile == "lite":
        candidates = LITE_LADDER
    else:
        raise ValueError(f"unknown profile: {profile}")
    return sorted({f for f in candidates
                   if f <= cap_khz and f not in existing and f in rates})


def opp_node(freq_khz: int, volt_uv: int, tol_max: int) -> str:
    hz = freq_khz * 1000
    return (
        f"\t\topp-{hz} {{\n"
        f"\t\t\topp-hz = /bits/ 64 <{hz}>;\n"
        f"\t\t\topp-microvolt = <{volt_uv} {volt_uv} {tol_max}>;\n"
        f"\t\t\tclock-latency-ns = <40000>;\n"
        f"\t\t}};\n\n"
    )


def insert_nodes_ordered(base: str, label: str,
                         new_specs: list[tuple[int, str]]) -> str:
    """Insert new OPP nodes at the position that keeps the table ordered by
    frequency. Pure insertion: no upstream line is ever removed or changed."""
    lines = base.splitlines(keepends=True)
    start_re = re.compile(r"^\t" + re.escape(label) + r": opp-table-cluster\d \{\s*$")
    start = next((i for i, l in enumerate(lines) if start_re.match(l)), None)
    if start is None:
        raise RuntimeError(f"{label}: table header not found; upstream DTSI changed")

    end = start + 1
    while end < len(lines) and lines[end].rstrip("\n") != "\t};":
        end += 1
    if end >= len(lines):
        raise RuntimeError(f"{label}: table end not found")

    opp_re = re.compile(r"^\t\topp-(\d+) \{")
    existing = []
    for i in range(start + 1, end):
        m = opp_re.match(lines[i])
        if m:
            existing.append((int(m.group(1)) // 1000, i))

    buckets: dict[int, list[str]] = {}
    for freq, text in new_specs:
        pos = next((idx for efreq, idx in existing if efreq > freq), end)
        buckets.setdefault(pos, []).append((freq, text))
    for pos in sorted(buckets, reverse=True):
        block = "".join(t for _, t in sorted(buckets[pos]))
        lines[pos:pos] = [block]
    return "".join(lines)


def build_dtsi(base: str, profile: str, lowvolt: bool) -> str:
    specs = [
        ("cluster0_opp_table", CLK_RATES_LIT, UPSTREAM_LIT,
         VOLT_LIT, 1800000, TOLERANCE_MAX_LIT),
        ("cluster1_opp_table", CLK_RATES_BIG, UPSTREAM_BIG,
         VOLT_BIG, 2400000, TOLERANCE_MAX_BIG),
        ("cluster2_opp_table", CLK_RATES_BIG, UPSTREAM_BIG,
         VOLT_BIG, 2400000, TOLERANCE_MAX_BIG),
    ]
    text = base
    for label, rates, existing, volt_ladder, cap, tol in specs:
        freqs = wanted_freqs(profile, rates, existing, cap)
        nodes = [(f, opp_node(f, voltage_for(f, volt_ladder, lowvolt), tol))
                 for f in freqs]
        text = insert_nodes_ordered(text, label, nodes)
    return text


def make_patch(base: str, new: str, profile: str, lowvolt: bool) -> str:
    diff = difflib.unified_diff(
        base.splitlines(keepends=False),
        new.splitlines(keepends=False),
        fromfile="a/" + DTSI_PATH,
        tofile="b/" + DTSI_PATH,
        n=3,
        lineterm="",
    )
    body = "\n".join(diff) + "\n"
    variant = "lowvolt" if lowvolt else "standard"
    header = (
        "From: E52C low-frequency OPP build <local>\n"
        f"Subject: arm64: dts: rockchip: expose full RK3588 CPU OPP ladder ({profile}/{variant})\n"
        "\n"
        "Mainline deliberately keeps only 5 (A55) / 7 (A76) OPPs. The\n"
        "rk3588 CPU clock driver already implements 96/216/312/408/... MHz;\n"
        "add OPP nodes for those rates so cpufreq-dt (and luci-app-cpufreq)\n"
        "can scale all the way down below 400 MHz.\n"
        "\n"
        "All frequencies are taken verbatim from rk3588_cpulclk_rates[] /\n"
        "rk3588_cpub0clk_rates[] / rk3588_cpub1clk_rates[] in\n"
        "drivers/clk/rockchip/clk-rk3588.c (Linux v6.12).\n"
        "Voltages are the conservative upstream/vendor ladder.\n"
        "\n"
        "---\n"
    )
    return header + body


def write_lf(path: Path, text: str) -> None:
    # Patches MUST be LF-only; pathlib.write_text() would emit CRLF on Windows.
    path.write_bytes(text.encode("utf-8"))


def main() -> None:
    base = BASE_FILE.read_text(encoding="utf-8")
    variants = [
        ("full", False, "900-rk3588-lowfreq-opp-full.patch"),
        ("lite", False, "901-rk3588-lowfreq-opp-lite.patch"),
        ("full", True, "902-rk3588-lowfreq-opp-full-lowvolt.patch"),
    ]
    for profile, lowvolt, filename in variants:
        new = build_dtsi(base, profile, lowvolt)
        patch = make_patch(base, new, profile, lowvolt)
        write_lf(PATCH_DIR / filename, patch)
        # Also emit the resulting full DTSI for DTB-only hot patching.
        suffix = filename.replace(".patch", "")
        write_lf(PATCH_DIR / (suffix + ".rk3588-opp.dtsi"), new)
        added = len(re.findall(r"^\+\t\topp-\d+ \{", patch, re.M))
        print(f"{filename}: +{added} OPP nodes, {len(patch.splitlines())} lines")

    # Device-tree fragment for people who only want to patch an existing DTB.
    frag = build_dtsi(base, "full", False)
    write_lf(PATCH_DIR / "result-rk3588-opp.dtsi.full", frag)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Static validation of the generated OPP patches. Run this before building:

    python3 tools/check_opp.py

It verifies that every added OPP is a frequency the RK3588 CPU clock driver
can actually produce, that voltages stay inside the E52C regulator window and
that the patch applies cleanly to the upstream v6.12 rk3588-opp.dtsi.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PATCH_DIR = ROOT / "patches"
sys.path.insert(0, str(HERE))

from gen_opp_patch import (  # noqa: E402
    CLK_RATES_BIG, CLK_RATES_LIT, DTSI_PATH, REG_MIN_UV, REG_MAX_UV,
    UPSTREAM_BIG, UPSTREAM_LIT, VOLT_BIG, VOLT_LIT,
)


def parse_tables(text: str) -> dict[str, list[tuple[int, int]]]:
    """Return {cluster label: [(freq_kHz, volt_uV), ...]}."""
    out: dict[str, list[tuple[int, int]]] = {}
    for label in ("cluster0_opp_table", "cluster1_opp_table", "cluster2_opp_table"):
        m = re.search(r"^\s*" + label + r":\s*opp-table-cluster\d\s*\{", text, re.M)
        if not m:
            raise AssertionError(f"{label}: table not found")
        start = m.end() - 1
        depth, end = 0, start
        while end < len(text):
            if text[end] == "{":
                depth += 1
            elif text[end] == "}":
                depth -= 1
                if depth == 0:
                    break
            end += 1
        body = text[start:end + 1]
        pairs = [
            (int(hz) // 1000, int(volt.split()[0]))
            for hz, volt in re.findall(
                r"opp-hz\s*=\s*/bits/\s*64\s*<(\d+)>;\s*"
                r"opp-microvolt\s*=\s*<([^>]+)>;", body
            )
        ]
        if not pairs:
            raise AssertionError(f"{label}: no OPP parsed")
        out[label] = pairs
    return out


def apply_patch(base: str, patch: str) -> str:
    """Minimal unified-diff applier (context = 3). Enough for our own patches."""
    lines = base.splitlines()
    plines = patch.splitlines()
    # locate diff header
    i = next(k for k, l in enumerate(plines) if l.startswith("--- a/"))
    plines = plines[i + 2:]  # skip --- and +++
    result, cursor = [], 0
    hunk_re = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")
    k = 0
    while k < len(plines):
        m = hunk_re.match(plines[k])
        if not m:
            k += 1
            continue
        old_start = int(m.group(1)) - 1
        result.extend(lines[cursor:old_start])
        cursor = old_start
        k += 1
        while k < len(plines) and not hunk_re.match(plines[k]):
            l = plines[k]
            if l.startswith(" "):
                assert lines[cursor] == l[1:], f"context mismatch at line {cursor + 1}"
                result.append(lines[cursor])
                cursor += 1
            elif l.startswith("-"):
                assert lines[cursor] == l[1:], f"removal mismatch at line {cursor + 1}"
                cursor += 1
            elif l.startswith("+"):
                result.append(l[1:])
            elif l == "":
                # tolerate a trailing empty context line
                result.append(lines[cursor])
                cursor += 1
            else:
                raise AssertionError(f"bad diff line: {l!r}")
            k += 1
    result.extend(lines[cursor:])
    return "\n".join(result) + "\n"


def check_variant(patch_name: str, expected_profile: str) -> None:
    base = (PATCH_DIR / "upstream-rk3588-opp.dtsi.v6.12").read_text(encoding="utf-8")
    patch = (PATCH_DIR / patch_name).read_text(encoding="utf-8")
    dtsi_name = patch_name.replace(".patch", ".rk3588-opp.dtsi")
    generated = (PATCH_DIR / dtsi_name).read_text(encoding="utf-8")

    rebuilt = apply_patch(base, patch)
    assert rebuilt == generated, f"{patch_name}: patch does not reproduce the DTSI"

    tables = parse_tables(generated)
    base_tables = parse_tables(base)

    for label, pairs in tables.items():
        rates = CLK_RATES_LIT if label == "cluster0_opp_table" else CLK_RATES_BIG
        volt_ladder = VOLT_LIT if label == "cluster0_opp_table" else VOLT_BIG
        existing = UPSTREAM_LIT if label == "cluster0_opp_table" else UPSTREAM_BIG
        freqs = [f for f, _ in pairs]
        assert freqs == sorted(freqs), f"{label}: OPPs not in ascending order"
        assert len(freqs) == len(set(freqs)), f"{label}: duplicate OPP frequency"
        for f, v in pairs:
            assert f in rates, f"{label}: {f} kHz is not a supported clock rate"
            assert REG_MIN_UV <= v <= REG_MAX_UV, f"{label}: {v} uV out of regulator range"
        # original OPP voltages must remain untouched
        orig = dict(base_tables[label])
        for f in existing:
            assert dict(pairs)[f] == orig[f], f"{label}: upstream OPP {f} was modified"
        # voltage must never be lower than the voltage of the next higher known OPP
        for f, v in pairs:
            expected = next((vv for ff, vv in sorted(volt_ladder) if ff >= f),
                            sorted(volt_ladder)[-1][1])
            if f >= 408000:
                assert v == expected, f"{label}: {f} kHz voltage {v} != {expected}"

        low = [f for f in freqs if f < 400000]
        assert len(low) >= 3, f"{label}: fewer than 3 sub-400 MHz OPPs"
        print(f"  {label}: {len(pairs):2d} OPPs, min {min(freqs)} kHz, "
              f"sub-400 MHz: {', '.join(str(x) for x in low)} kHz")

    assert expected_profile in patch
    print(f"OK  {patch_name}  (applies cleanly, {len(patch.splitlines())} lines)")


def main() -> None:
    variants = [
        ("900-rk3588-lowfreq-opp-full.patch", "full/standard"),
        ("901-rk3588-lowfreq-opp-lite.patch", "lite/standard"),
        ("902-rk3588-lowfreq-opp-full-lowvolt.patch", "full/lowvolt"),
    ]
    for name, profile in variants:
        print(f"\n== {name} ==")
        check_variant(name, profile)
    print("\nAll OPP patches validated.")


if __name__ == "__main__":
    main()

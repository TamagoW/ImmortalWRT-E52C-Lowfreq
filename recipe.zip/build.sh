#!/usr/bin/env bash
# =============================================================================
# ImmortalWrt for Radxa E52C - full CPU OPP ladder (down to 96 MHz)
#
# What this script does
#   1. clones ImmortalWrt openwrt-25.12 (kernel 6.12, APK based)
#   2. verifies the RK3582 core-unlock U-Boot patch is still present
#   3. installs the low-frequency OPP kernel patch into patches-<kernelver>
#   4. writes .config from config/config.seed (locks the exact package list)
#   5. builds sysupgrade images and collects them into ./out
#
# Requirements: x86_64 GNU/Linux (Debian 11+/Ubuntu 22.04+), case-sensitive FS,
#               >= 4 cores, >= 8 GiB RAM, >= 40 GiB free disk, Internet.
#               Cygwin / MSYS2 / Git-Bash are NOT supported by OpenWrt.
#
# Usage:
#   ./build.sh                      # default: full OPP ladder, CHINA mirrors
#   OPP_PATCH=901-rk3588-lowfreq-opp-lite.patch ./build.sh
#   OPP_PATCH=902-rk3588-lowfreq-opp-full-lowvolt.patch ./build.sh  # experimental
#   MIRROR_PROFILE=direct ./build.sh              # GitHub Actions / overseas hosts
#   IW_BRANCH=openwrt-25.12 JOBS=8 ./build.sh
#
# Mirror variables (defaults are China-optimised):
#   MIRROR_PROFILE   china | direct
#   IW_REPO          main source tree git URL
#   GH_MIRROR_PREFIX prefix for all github.com / raw.githubusercontent.com URLs
#   DOWNLOAD_MIRROR  extra ;-separated dl mirrors (scripts/download.pl)
#   FALLBACK_GH      secondary proxy used if the primary clone fails
#
# Output: out/immortalwrt-*-radxa_e52c-*-sysupgrade.img.gz
# =============================================================================
set -Eeuo pipefail
export LC_ALL=C

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ---------------------------------------------------------------- mirrors ---
# "china" routes git + raw downloads through a tested Chinese GitHub proxy.
# ImmortalWrt 25.12's scripts/projectsmirrors.json ALREADY lists Chinese
# mirrors first for @GNU / @KERNEL / @DEBIAN / @APACHE, so source tarballs
# are domestic by default too; we only add the proxy to @GITHUB below.
MIRROR_PROFILE="${MIRROR_PROFILE:-china}"
case "$MIRROR_PROFILE" in
  china)
    DEF_IW_REPO="https://gh-proxy.com/https://github.com/immortalwrt/immortalwrt.git"
    DEF_GH_PREFIX="https://gh-proxy.com/"
    DEF_FALLBACK="https://ghfast.top/"
    ;;
  direct)
    DEF_IW_REPO="https://github.com/immortalwrt/immortalwrt.git"
    DEF_GH_PREFIX=""
    DEF_FALLBACK=""
    ;;
  *) printf '\033[1;31m[FAIL]\033[0m MIRROR_PROFILE must be china or direct (got: %s)\n' "$MIRROR_PROFILE" >&2; exit 1 ;;
esac
IW_REPO="${IW_REPO:-$DEF_IW_REPO}"
GH_MIRROR_PREFIX="${GH_MIRROR_PREFIX:-$DEF_GH_PREFIX}"
FALLBACK_GH="${FALLBACK_GH:-$DEF_FALLBACK}"
DOWNLOAD_MIRROR="${DOWNLOAD_MIRROR:-}"
export DOWNLOAD_MIRROR

# v25.12.2 is a RELEASE TAG: kernel 6.12.103 + all five feeds pinned to exact
# commit hashes (feeds.conf.default uses ^<sha>). The rolling openwrt-25.12
# branch moved to kernel 6.12.116 without refreshing the v6.15 DRM/VOP2
# backports, which makes `make` die with "Patch failed!" on the first build.
IW_BRANCH="${IW_BRANCH:-v25.12.2}"
STABLE_TAG="${STABLE_TAG:-v25.12.2}"
OPP_PATCH="${OPP_PATCH:-900-rk3588-lowfreq-opp-full.patch}"
JOBS="${JOBS:-$(nproc)}"
STRICT_PACKAGES="${STRICT_PACKAGES:-1}"
SRC="${SRC:-$HERE/build/immortalwrt}"
OUTDIR="${OUTDIR:-$HERE/out}"

log()  { printf '\n\033[1;36m[E52C]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[WARN]\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[1;31m[FAIL]\033[0m %s\n' "$*" >&2; exit 1; }

# Older workflow revisions still pass IW_BRANCH=openwrt-25.12. Auto-pin them to
# the release tag so a user only has to re-run (or re-upload recipe.zip).
# Set IW_ALLOW_ROLLING=1 to explicitly keep the rolling branch.
if [ "$IW_BRANCH" = "openwrt-25.12" ] && [ "${IW_ALLOW_ROLLING:-0}" != "1" ]; then
  warn "IW_BRANCH=openwrt-25.12 is a rolling branch: kernel 6.12.116 breaks the v6.15 VOP2 backports."
  warn "Auto-pinning to release tag $STABLE_TAG (kernel 6.12.103, feeds frozen to exact commits)."
  IW_BRANCH="$STABLE_TAG"
fi
log "ImmortalWrt ref: $IW_BRANCH"

# ---------------------------------------------------------------- environment
case "$(uname -s)" in
  Linux) ;;
  *) die "ImmortalWrt must be built on GNU/Linux (case-sensitive filesystem).
   This script is running under $(uname -s).
   Use WSL2 (Ubuntu), a Linux VM, Docker, or the GitHub Actions workflow
   in .github/workflows/build.yml." ;;
esac

for t in git make gcc g++ python3 curl patch gzip xz bison flex gawk \
         unzip file; do
  command -v "${t%% *}" >/dev/null 2>&1 || missing_tools="${missing_tools:-} ${t%% *}"
done
if [ -n "${missing_tools:-}" ]; then
  warn "Missing build dependencies:$missing_tools"
  printf '\n  On Debian/Ubuntu install them with:\n'
  printf '  sudo apt update && sudo apt install -y build-essential clang flex bison g++ gawk \\\n'
  printf '    gcc-multilib g++-multilib gettext git libncurses-dev libssl-dev \\\n'
  printf '    python3-distutils rsync unzip zlib1g-dev file wget curl ccache \\\n'
  printf '    device-tree-compiler libelf-dev ecj fastjar libglib2.0-dev intltool \\\n'
  printf '    python3-pyelftools python3-setuptools swig\n\n'
  die "install the dependencies above, then re-run."
fi

# U-Boot binman (used by the RK3588 bootloader, and therefore by the core-unlock
# image) needs Python's elftools module. OpenWrt 25.12 checks it with
#   $(STAGING_DIR_HOST)/bin/python3 -c 'import elftools'
# and that host python3 is a symlink to the system python, so installing the
# distro module is enough. On GitHub Actions we self-heal so users do not have
# to edit the workflow just to add one apt package.
if ! python3 -c 'import elftools' >/dev/null 2>&1; then
  if [ "${GITHUB_ACTIONS:-}" = "true" ]; then
    log "Host module pyelftools missing - installing it (U-Boot binman prerequisite) ..."
    ( sudo apt-get update -qq && sudo apt-get install -y --no-install-recommends \
        python3-pyelftools python3-cryptography python3-setuptools \
        python3-pip swig ) >/dev/null 2>&1 || true
    if ! python3 -c 'import elftools' >/dev/null 2>&1; then
      python3 -m pip install --break-system-packages pyelftools >/dev/null 2>&1 \
        || python3 -m pip install --user pyelftools >/dev/null 2>&1 \
        || pip3 install --break-system-packages pyelftools >/dev/null 2>&1 || true
    fi
  fi
  if ! python3 -c 'import elftools' >/dev/null 2>&1; then
    warn "Missing Python module 'elftools' (required by U-Boot binman)."
    warn "  Ubuntu/Debian: sudo apt install -y python3-pyelftools python3-setuptools swig"
    warn "  or: pip3 install --break-system-packages pyelftools"
    die "install it and re-run (or fix the workflow's dependency step)."
  fi
  log "pyelftools installed."
fi

[ -f "$HERE/config/config.seed" ]    || die "config/config.seed missing"
[ -f "$HERE/config/packages.list" ]  || die "config/packages.list missing"
[ -f "$HERE/patches/$OPP_PATCH" ]    || die "patches/$OPP_PATCH missing"
mkdir -p "$(dirname "$SRC")" "$OUTDIR"

# ------------------------------------------------------- 0. mirror wiring ---
GIT_KEY=""
if [ -n "$GH_MIRROR_PREFIX" ]; then
  # Use a PRIVATE global git config so we never touch the host's ~/.gitconfig.
  MIRROR_CFG="$HERE/build/.gitconfig-mirror"
  mkdir -p "$(dirname "$MIRROR_CFG")"
  : > "$MIRROR_CFG"
  export GIT_CONFIG_GLOBAL="$MIRROR_CFG"
  git config --global user.name  "E52C Builder"
  git config --global user.email "builder@localhost"
  # Covers the 5 feeds repos, git-based PKG_SOURCE_PROTO downloads and any
  # submodules - everything that starts with https://github.com/.
  GIT_KEY="url.${GH_MIRROR_PREFIX}https://github.com/.insteadOf"
  git config --global "$GIT_KEY" "https://github.com/"
  cleanup_mirror() { rm -f "$MIRROR_CFG"; }
  trap cleanup_mirror EXIT
  log "Mirror profile: CHINA"
  log "  main repo : $IW_REPO"
  log "  github    : ${GH_MIRROR_PREFIX}https://github.com/  (feeds + git sources)"
  log "  fallback  : ${FALLBACK_GH:-direct github.com}"
else
  log "Mirror profile: DIRECT (native github.com)"
fi

# ------------------------------------------------------------------ 1. clone
if [ ! -d "$SRC/.git" ]; then
  log "Cloning ImmortalWrt ($IW_BRANCH) ..."
  if ! git clone --depth 1 --branch "$IW_BRANCH" "$IW_REPO" "$SRC"; then
    warn "Primary mirror clone failed; removing git rewrite and retrying."
    [ -n "$GIT_KEY" ] && git config --global --unset-all "$GIT_KEY" >/dev/null 2>&1 || true
    rm -rf "$SRC"
    ok=0
    if [ -n "$FALLBACK_GH" ]; then
      ALT="${FALLBACK_GH}https://github.com/immortalwrt/immortalwrt.git"
      log "Secondary proxy: $ALT"
      if git clone --depth 1 --branch "$IW_BRANCH" "$ALT" "$SRC"; then ok=1; else rm -rf "$SRC"; fi
    fi
    if [ "$ok" -eq 0 ]; then
      log "Falling back to direct github.com ..."
      git clone --depth 1 --branch "$IW_BRANCH" \
        "https://github.com/immortalwrt/immortalwrt.git" "$SRC"
    fi
    warn "Build continues without the git mirror (feeds will use the URL above)."
  fi
else
  log "Reusing existing source tree at $SRC"
fi
cd "$SRC"
log "HEAD: $(git rev-parse --short HEAD)  ref: ${IW_BRANCH}  kernel: $(sed -n 's/^LINUX_VERSION-6\.12 *= *\.\([0-9]*\).*/6.12.\1/p' target/linux/generic/kernel-6.12 | head -1)"

# Defensive: if the rolling branch was forced (IW_ALLOW_ROLLING=1), the v6.15
# DRM/VOP2 backport no longer applies to kernel 6.12.116. The E52C has no GPU
# and no display output, so dropping that cosmetic patch is lossless.
KVER_FILE="target/linux/generic/kernel-6.12"
if [ -f "$KVER_FILE" ] && grep -q 'LINUX_VERSION-6.12 = .116' "$KVER_FILE"; then
  for p in target/linux/rockchip/patches-6.12/*v6.15-drm-rockchip-vop2*.patch; do
    [ -f "$p" ] || continue
    mv "$p" "$p.disabled"
    warn "Disabled incompatible display-only patch: $(basename "$p") (E52C has no GPU/VOP2)."
  done
fi

# Add the Chinese proxy in front of @GITHUB in scripts/projectsmirrors.json.
# @GNU / @KERNEL / @DEBIAN / @APACHE are already CN-first upstream, so only
# raw.githubusercontent.com needs help. download.pl tries each mirror in
# order, so the original entry stays as an automatic fallback.
if [ -n "$GH_MIRROR_PREFIX" ] && [ -f scripts/projectsmirrors.json ]; then
  GH_MIRROR_PREFIX="$GH_MIRROR_PREFIX" python3 - <<'PY'
import json, os
p = "scripts/projectsmirrors.json"
prefix = os.environ["GH_MIRROR_PREFIX"].rstrip("/")
proxy = prefix + "/https://raw.githubusercontent.com"
with open(p, encoding="utf-8") as f:
    data = json.load(f)
data["@GITHUB"] = [proxy] + [u for u in data["@GITHUB"] if u != proxy]
with open(p, "w", encoding="utf-8") as f:
    json.dump(data, f, indent="\t", ensure_ascii=False)
print("  projectsmirrors: @GITHUB ->", data["@GITHUB"])
PY
fi

# --------------------------------------------- 2. preserve the core unlock ---
# RK3582 ships with one A76 cluster fused off. ImmortalWrt unlocks it in
# U-Boot's ft_system_setup() with this patch. The E52C image uses
# UBOOT_DEVICE_NAME=generic-rk3588 and pine64-img embeds that u-boot binary
# into sysupgrade.img.gz, so losing this patch loses the 8-core unlock.
UNLOCK_PATCH="package/boot/uboot-rockchip/patches/900-enable-good-state-big-bluster2-for-rk3582.patch"
[ -f "$UNLOCK_PATCH" ] || die "Core-unlock U-Boot patch is missing:
   $UNLOCK_PATCH
   Refusing to build a firmware that would lose the 8-core unlock."
grep -q '#if 0' "$UNLOCK_PATCH" || warn "Unlock patch content changed - please verify it still disables FAIL_CPU_CLUSTER2."
grep -q 'FAIL_CPU_CLUSTER2' "$UNLOCK_PATCH" || warn "Unlock patch does not mention FAIL_CPU_CLUSTER2 - manual review needed."
log "Core-unlock U-Boot patch present (8-core unlock preserved)."

# ------------------------------------------------------- 3. install OPP patch
KVER="$(sed -n 's/^KERNEL_PATCHVER:=\([0-9.]*\)/\1/p' target/linux/rockchip/Makefile | head -1)"
[ -n "$KVER" ] || die "cannot read KERNEL_PATCHVER from target/linux/rockchip/Makefile"
PDIR="target/linux/rockchip/patches-$KVER"
[ -d "$PDIR" ] || die "patch directory $PDIR does not exist (branch/kernel mismatch)"
log "Kernel $KVER -> installing $OPP_PATCH into $PDIR/"
# Only one OPP variant may be active; remove any other variants first.
find "$PDIR" -maxdepth 1 -name '*rk3588-lowfreq-opp*.patch' -delete
cp "$HERE/patches/$OPP_PATCH" "$PDIR/"
# Local dry-run: prove the patch applies to the unpacked kernel tree later,
# but at least make sure it is a well-formed patch with the expected target.
grep -q 'rk3588-opp.dtsi' "$PDIR/$OPP_PATCH" || die "OPP patch does not target rk3588-opp.dtsi"

# --------------------------------------------------------------- 4. feeds ---
# The v25.12.2 source tree ships SIX feeds in feeds.conf.default, but the
# official 25.12.2 RELEASE feeds.conf publishes only five (base, packages,
# luci, routing, telephony) - there is no "video" package directory on any
# release mirror. Installing the extra video feed makes the image's
# /etc/apk/repositories.d/distfeeds.list point at .../video/packages.adb,
# which 404s on every `apk update` (wget exit 8 / unexpected end of file).
# Mirror the release feeds.conf so apk sources all resolve.
if [ -f feeds.conf.default ] && grep -q '^src-git video ' feeds.conf.default; then
  grep -v '^src-git video ' feeds.conf.default > feeds.conf
  log "Dropped the 'video' feed (not published in 25.12.2) so apk repositories stay valid."
fi

log "Updating and installing feeds (luci / packages / routing / telephony) ..."
if ! ./scripts/feeds update -a; then
  warn "feeds update through the mirror failed; dropping git rewrite and retrying direct."
  [ -n "$GIT_KEY" ] && git config --global --unset-all "$GIT_KEY" >/dev/null 2>&1 || true
  ./scripts/feeds update -a
fi
./scripts/feeds install -a

# ------------------------------------------------------------- 5. .config ---
log "Writing .config from config.seed ..."
cp "$HERE/config/config.seed" .config
if ! make defconfig > "$HERE/defconfig.log" 2>&1; then
  tail -n 40 "$HERE/defconfig.log" >&2
  die "make defconfig failed - see defconfig.log"
fi
# ImmortalWrt 25.12 feeds contain a few packages whose DEPENDS self-reference
# (dnsdist / snort3 / knot-resolver / luci-app-weechat / openappid). Kconfig
# prints "recursive dependency detected" but still exits 0 and the resulting
# .config is valid. Explain it instead of letting it look like a hard failure.
if grep -q "recursive dependency detected" "$HERE/defconfig.log"; then
  warn "Upstream feeds emitted non-fatal Kconfig 'recursive dependency detected' notices."
  warn "make defconfig completed successfully; these do not affect the image. Full text: defconfig.log"
  grep "recursive dependency detected" "$HERE/defconfig.log" | head -6 >&2 || true
fi

grep -q '^CONFIG_TARGET_rockchip_armv8=y' .config \
  || die "target rockchip/armv8 was not selected; inspect .config"
# Two valid spellings: single-profile choice, or multi-profile menuconfig.
if ! grep -q '^CONFIG_TARGET_rockchip_armv8_DEVICE_radxa_e52c=y' .config \
   && ! grep -q '^CONFIG_TARGET_DEVICE_rockchip_armv8_DEVICE_radxa_e52c=y' .config; then
  warn "E52C device profile symbol not accepted. CONFIG_TARGET lines:"
  grep '^CONFIG_TARGET' .config | head -30
  die "fix the profile symbol in config/config.seed for this branch (otherwise every armv8 board gets built)."
fi
if grep -q '^CONFIG_TARGET_MULTI_PROFILE=y' .config; then
  warn "TARGET_MULTI_PROFILE is enabled - verify only radxa_e52c is selected."
fi
log "E52C profile selected (single device build)."

# Verify every requested package survived defconfig.
MISSING=""
SOFT="libc libgcc base-files"   # supplied by the toolchain, may not be a PACKAGE symbol
while IFS= read -r pkg; do
  case "$pkg" in ''|'#'*) continue ;; esac
  pkg="${pkg%%#*}"; pkg="$(echo "$pkg" | tr -d '[:space:]')"
  [ -z "$pkg" ] && continue
  if ! grep -q "^CONFIG_PACKAGE_${pkg}=y" .config; then
    case " $SOFT " in *" $pkg "*) continue ;; esac
    MISSING="$MISSING $pkg"
  fi
done < "$HERE/config/packages.list"

if [ -n "$MISSING" ]; then
  printf '%s\n' "$MISSING" | tr ' ' '\n' | sed '/^$/d' > "$OUTDIR/MISSING_PACKAGES.txt"
  warn "These packages were dropped by defconfig (renamed / not in feeds):$MISSING"
  warn "Full list: $OUTDIR/MISSING_PACKAGES.txt"
  warn "Hint: some names are PROVIDES virtuals on 25.12 (e.g. nftables -> nftables-json); map to the real variant."
  [ "$STRICT_PACKAGES" = "1" ] && die "set STRICT_PACKAGES=0 to build anyway, or fix the package names."
else
  log "All requested packages are selected in .config."
fi

# ---------------------------------------------------------------- 6. build ---
log "Downloading sources (make download -j$JOBS) ..."
make download -j"$JOBS"

log "Building (make -j$JOBS V=s). First build typically takes 1-3 hours."
make -j"$JOBS" V=s 2>&1 | tee "$HERE/build.log"

# ------------------------------------------------------------- 7. artifacts ---
log "Collecting artifacts ..."
FOUND=0
while IFS= read -r f; do
  cp -f "$f" "$OUTDIR/"
  FOUND=$((FOUND+1))
done < <(find bin/targets/rockchip/armv8 -maxdepth 1 -type f \
          \( -name '*radxa_e52c*' -o -name 'sha256sums' \) -print)

[ "$FOUND" -gt 0 ] || die "no E52C images produced - check build.log"

# Sanity: the U-Boot binary that carries the unlock must exist in staging.
UBOOT_BIN="$(find staging_dir -type f -name 'generic-rk3588*u-boot*' 2>/dev/null | head -1 || true)"
if [ -n "$UBOOT_BIN" ]; then
  log "Unlock U-Boot binary: $UBOOT_BIN"
else
  warn "Could not locate generic-rk3588 u-boot binary in staging_dir; verify the flashed image keeps 8 cores."
fi

( cd "$OUTDIR" && sha256sum immortalwrt-*radxa_e52c-* > SHA256SUMS.txt 2>/dev/null || true )
log "Done. Images are in: $OUTDIR"
ls -lh "$OUTDIR"
printf '\nNext: flash *-squashfs-sysupgrade.img.gz with LuCI (keep settings OFF),\n'
printf 'then run verify/verify-freq.sh on the device.\n'
